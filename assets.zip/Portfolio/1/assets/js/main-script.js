$(document).ready(function(){
    $('nav > div > ul > li > a').click(function(){
        $('#navbarNav').removeClass('show');
    })
});